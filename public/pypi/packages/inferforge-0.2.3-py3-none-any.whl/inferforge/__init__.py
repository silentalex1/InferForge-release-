__version__ = "0.2.3"
__app_name__ = "InferForge"