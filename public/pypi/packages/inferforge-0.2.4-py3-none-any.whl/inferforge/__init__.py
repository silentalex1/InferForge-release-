__version__ = "0.2.4"
__app_name__ = "InferForge"