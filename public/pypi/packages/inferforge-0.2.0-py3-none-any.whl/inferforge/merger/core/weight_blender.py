"""
Weight blending algorithms for model merging.

Implements multiple sophisticated merging strategies:
- SLERP (Spherical Linear Interpolation)
- TIES (Task Iteration and Ejection Sign)
- MoE (Mixture of Experts) routing
"""

import torch
import numpy as np
from typing import List, Dict, Optional, Tuple, Union
from enum import Enum
from dataclasses import dataclass


class MergeStrategy(Enum):
    """Available merging strategies."""
    SLERP = "slerp"
    TIES = "ties"
    MOE = "moe"
    LINEAR = "linear"
    SIMPLE_AVERAGE = "simple_average"


@dataclass
class MergeConfig:
    """Configuration for weight merging."""
    strategy: MergeStrategy = MergeStrategy.TIES
    interpolation: float = 0.5                                                  
    ties_param_k: float = 0.2                                      
    ties_lambda: float = 0.5                           
    moe_num_experts: int = 4                             
    moe_top_k: int = 2                             
    precision: str = "bfloat16"                    
    normalize: bool = False


class WeightBlender:
    """Advanced weight blending for model merging."""
    
    def __init__(self, config: Optional[MergeConfig] = None):
        """
        Initialize weight blender.
        
        Args:
            config: Merge configuration, uses defaults if None
        """
        self.config = config or MergeConfig()
        
    def slerp(self, val: float, low: torch.Tensor, high: torch.Tensor) -> torch.Tensor:
        """
        Spherical linear interpolation for precise geometric weight blending.
        
        Args:
            val: Interpolation value (0.0 = low, 1.0 = high)
            low: Starting tensor
            high: Ending tensor
        
        Returns:
            Interpolated tensor
        """
                           
        low_norm = low / torch.norm(low)
        high_norm = high / torch.norm(high)
        
                                         
        omega = torch.acos(torch.clamp(torch.dot(low_norm.flatten(), high_norm.flatten()), -1.0, 1.0))
        so = torch.sin(omega)
        
        if so < 1e-8:
                                                                              
            return (1.0 - val) * low + val * high
        
                       
        return torch.sin((1.0 - val) * omega) / so * low + torch.sin(val * omega) / so * high
    
    def ties_merge(
        self,
        weights: List[torch.Tensor],
        base_weights: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        TIES merging: Trim, Elect Sign, Disjoint Merge.
        
        Args:
            weights: List of weight tensors to merge
            base_weights: Optional base model weights for delta calculation
        
        Returns:
            Merged weight tensor
        """
        if not weights:
            raise ValueError("No weights provided for merging")
        
                                                   
        if base_weights is not None:
            deltas = [w - base_weights for w in weights]
        else:
            deltas = weights
        
                                                         
        k = self.config.ties_param_k
        trimmed_deltas = []
        
        for delta in deltas:
                                 
            magnitude = torch.abs(delta)
            threshold = torch.quantile(magnitude, 1.0 - k)
            
                                    
            mask = magnitude >= threshold
            trimmed_delta = delta * mask.float()
            trimmed_deltas.append(trimmed_delta)
        
                                                             
        if len(trimmed_deltas) > 1:
            signs = [torch.sign(d) for d in trimmed_deltas]
            stacked_signs = torch.stack(signs)
            
                           
            sign_sum = torch.sum(stacked_signs, dim=0)
            majority_sign = torch.sign(sign_sum)
            
                                 
            for i in range(len(trimmed_deltas)):
                trimmed_deltas[i] = torch.abs(trimmed_deltas[i]) * majority_sign
        
                                                                      
        if len(trimmed_deltas) > 1:
            stacked_deltas = torch.stack(trimmed_deltas)
            
                                 
            first_sign = torch.sign(trimmed_deltas[0])
            agreement_mask = torch.all(
                torch.sign(stacked_deltas) == first_sign.unsqueeze(0), dim=0
            )
            
                                           
            merged_delta = torch.zeros_like(trimmed_deltas[0])
            if agreement_mask.any():
                merged_delta[agreement_mask] = torch.mean(
                    stacked_deltas[:, agreement_mask], dim=0
                )
        else:
            merged_delta = trimmed_deltas[0]
        
                                           
        if base_weights is not None:
            result = base_weights + merged_delta
        else:
            result = merged_delta
        
        return result
    
    def moe_routing(
        self,
        expert_weights: List[torch.Tensor],
        input_tensor: torch.Tensor
    ) -> torch.Tensor:
        """
        Mixture of Experts routing.
        
        Args:
            expert_weights: List of expert weight tensors
            input_tensor: Input tensor for routing decision
        
        Returns:
            Output from routed expert
        """
                                                               
        num_experts = len(expert_weights)
        if num_experts == 1:
            return torch.matmul(input_tensor, expert_weights[0])
        
                                               
        input_norm = torch.norm(input_tensor)
        expert_idx = int(input_norm) % num_experts
        
                             
        selected_expert = expert_weights[expert_idx]
        return torch.matmul(input_tensor, selected_expert)
    
    def linear_interpolate(
        self,
        weights: List[torch.Tensor],
        interpolation: Optional[float] = None
    ) -> torch.Tensor:
        """
        Linear interpolation between weights.
        
        Args:
            weights: List of weight tensors
            interpolation: Interpolation value (uses config default if None)
        
        Returns:
            Interpolated weight tensor
        """
        if not weights:
            raise ValueError("No weights provided for interpolation")
        
        if interpolation is None:
            interpolation = self.config.interpolation
        
        if len(weights) == 1:
            return weights[0]
        
                                                  
        result = weights[0]
        for i in range(1, len(weights)):
            weight = weights[i]
                                                     
            step_factor = interpolation / len(weights)
            result = (1.0 - step_factor) * result + step_factor * weight
        
        return result
    
    def simple_average(self, weights: List[torch.Tensor]) -> torch.Tensor:
        """Simple average of weights."""
        if not weights:
            raise ValueError("No weights provided for averaging")
        
        stacked = torch.stack(weights)
        return torch.mean(stacked, dim=0)
    
    def merge_weights(
        self,
        weights: List[torch.Tensor],
        base_weights: Optional[torch.Tensor] = None,
        strategy: Optional[MergeStrategy] = None
    ) -> torch.Tensor:
        """
        Main weight merging function.
        
        Args:
            weights: List of weight tensors to merge
            base_weights: Optional base model weights
            strategy: Merge strategy (uses config default if None)
        
        Returns:
            Merged weight tensor
        """
        if not weights:
            raise ValueError("No weights provided for merging")
        
        if strategy is None:
            strategy = self.config.strategy
        
                                            
        target_dtype = self._get_target_dtype()
        weights = [w.to(target_dtype) for w in weights]
        
        if base_weights is not None:
            base_weights = base_weights.to(target_dtype)
        
                                
        if self.config.normalize:
            weights = [self._normalize_tensor(w) for w in weights]
            if base_weights is not None:
                base_weights = self._normalize_tensor(base_weights)
        
                                         
        weights = self._match_group(weights)
        if base_weights is not None and base_weights.shape != weights[0].shape:
            base_weights = self._match_to(base_weights, weights[0].shape)

        if strategy == MergeStrategy.SLERP:
            result = weights[0]
            for other in weights[1:]:
                result = self.slerp(self.config.interpolation, result, other)
        elif strategy == MergeStrategy.TIES:
            result = self.ties_merge(weights, base_weights)
        elif strategy == MergeStrategy.MOE:
            result = self._moe_blend(weights)
        elif strategy == MergeStrategy.LINEAR:
            result = self.linear_interpolate(weights)
        elif strategy == MergeStrategy.SIMPLE_AVERAGE:
            result = self.simple_average(weights)
        else:
            raise ValueError(f"Unknown merge strategy: {strategy}")
        return result

    def merge_state_dicts(
        self,
        state_dicts: List[Dict[str, torch.Tensor]],
        base: Optional[Dict[str, torch.Tensor]] = None,
    ) -> Dict[str, torch.Tensor]:
        if not state_dicts:
            raise ValueError("No state dicts provided for merging")
        keys: set[str] = set()
        for state in state_dicts:
            keys.update(state.keys())
        merged: Dict[str, torch.Tensor] = {}
        for key in keys:
            tensors = [state[key] for state in state_dicts if key in state]
            if not tensors:
                continue
            if len(tensors) == 1:
                merged[key] = tensors[0]
                continue
            base_tensor = base.get(key) if base else tensors[0]
            merged[key] = self.merge_weights(tensors, base_weights=base_tensor)
        return merged

    def _match_group(self, weights: List[torch.Tensor]) -> List[torch.Tensor]:
        reference = weights[0]
        return [self._match_to(tensor, reference.shape) for tensor in weights]

    def _match_to(self, tensor: torch.Tensor, shape: Tuple[int, ...]) -> torch.Tensor:
        if tensor.shape == shape:
            return tensor
        from inferforge.merger.core.tensor_utils import TensorUtils

        return TensorUtils.match_shape(tensor, shape)

    def _moe_blend(self, weights: List[torch.Tensor]) -> torch.Tensor:
        norms = torch.stack([torch.norm(tensor.float()) + 1e-8 for tensor in weights])
        gates = norms / norms.sum()
        result = torch.zeros_like(weights[0])
        for gate, tensor in zip(gates, weights):
            result = result + tensor * gate.to(tensor.dtype)
        return result
    
    def _get_target_dtype(self) -> torch.dtype:
        """Get target dtype from config."""
        dtype_map = {
            "float32": torch.float32,
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float8_e4m3fn": torch.float8_e4m3fn,
        }
        return dtype_map.get(self.config.precision, torch.bfloat16)
    
    def _normalize_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        """Normalize tensor to prevent numerical issues."""
        norm = torch.norm(tensor)
        if norm < 1e-8:
            return tensor
        return tensor / norm
    
    def calculate_parameters(self, model_dict: Dict[str, torch.Tensor]) -> int:
        """
        Calculate total parameters in a model dictionary.
        
        Args:
            model_dict: Dictionary of parameter name -> tensor
        
        Returns:
            Total number of parameters
        """
        return sum(tensor.numel() for tensor in model_dict.values())
    
    def estimate_moe_parameters(
        self,
        base_params: int,
        num_experts: int,
        expert_param_ratio: float = 0.5
    ) -> int:
        """
        Estimate parameters for MoE model.
        
        Args:
            base_params: Parameters in base model
            num_experts: Number of experts
            expert_param_ratio: Ratio of parameters that become expert-specific
        
        Returns:
            Estimated total parameters
        """
        shared_params = base_params * (1.0 - expert_param_ratio)
        expert_params = base_params * expert_param_ratio * num_experts
        routing_params = base_params * 0.01                   
        
        return int(shared_params + expert_params + routing_params)
