"""
Procrustes Alignment for Architecture-Agnostic Model Merging.

Uses orthogonal Procrustes rotation matrices to mathematically align the 
vector spaces of different models before combining them. This allows merging
models with different architectures by rotating their weight matrices to 
"speak the same geometric language."
"""

import torch
import numpy as np
from typing import Tuple, Optional
from scipy.linalg import orthogonal_procrustes
from scipy.optimize import linear_sum_assignment


class ProcrustesAligner:
    """Aligns different model architectures using Procrustes analysis."""
    
    @staticmethod
    def orthogonal_procrustes(
        source: torch.Tensor,
        target: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute optimal orthogonal transformation to align source to target.
        
        Args:
            source: Source weight matrix [d1, d2]
            target: Target weight matrix [d1, d2]
        
        Returns:
            Tuple of (rotation_matrix, aligned_source)
        """
                                    
        source_np = source.detach().cpu().numpy()
        target_np = target.detach().cpu().numpy()
        
                                
        if source_np.ndim == 1:
            source_np = source_np.reshape(-1, 1)
        if target_np.ndim == 1:
            target_np = target_np.reshape(-1, 1)
        
                                                              
        R, _ = orthogonal_procrustes(source_np, target_np)
        
                                  
        aligned_source_np = source_np @ R
        
                               
        rotation_matrix = torch.from_numpy(R).to(source.dtype).to(source.device)
        aligned_source = torch.from_numpy(aligned_source_np).to(source.dtype).to(source.device)
        
        return rotation_matrix, aligned_source
    
    @staticmethod
    def central_kernel_alignment(
        matrix_a: torch.Tensor,
        matrix_b: torch.Tensor,
        layer_name: str = ""
    ) -> float:
        """
        Compute Central Kernel Alignment (CKA) similarity between two weight matrices.
        
        CKA measures the similarity of neural network representations and is
        architecture-agnostic, making it perfect for matching layers across
        different model architectures.
        
        Args:
            matrix_a: First weight matrix
            matrix_b: Second weight matrix
            layer_name: Optional layer identifier for logging
        
        Returns:
            CKA similarity score (0.0 to 1.0)
        """
                                              
        a_flat = matrix_a.flatten().detach().cpu().numpy()
        b_flat = matrix_b.flatten().detach().cpu().numpy()
        
                                                       
        min_size = min(a_flat.shape[0], b_flat.shape[0])
        a_flat = a_flat[:min_size]
        b_flat = b_flat[:min_size]
        
                                          
        def centered_kernel(X):
            X_centered = X - X.mean()
            K = X_centered @ X_centered.T
            return K
        
        K_a = centered_kernel(a_flat.reshape(-1, 1))
        K_b = centered_kernel(b_flat.reshape(-1, 1))
        
                                                               
        def hsic(K1, K2):
            n = K1.shape[0]
            H = torch.eye(n) - (1.0 / n) * torch.ones(n, n)
            H_K1_H = H @ K1 @ H
            H_K2_H = H @ K2 @ H
            return torch.trace(H_K1_H @ H_K2_H)
        
        K_a_torch = torch.from_numpy(K_a).float()
        K_b_torch = torch.from_numpy(K_b).float()
        
        hsic_aa = hsic(K_a_torch, K_a_torch)
        hsic_bb = hsic(K_b_torch, K_b_torch)
        hsic_ab = hsic(K_a_torch, K_b_torch)
        
                     
        cka = hsic_ab / (torch.sqrt(hsic_aa * hsic_bb) + 1e-8)
        
        return cka.item()
    
    @staticmethod
    def Hungarian_weight_matching(
        weights_a: torch.Tensor,
        weights_b: torch.Tensor
    ) -> Tuple[torch.Tensor, np.ndarray]:
        """
        Match neurons between layers using Hungarian algorithm.
        
        Neutral networks can learn the same concepts but store them in different
        neuron layouts. This algorithm reorders neurons to align semantically.
        
        Args:
            weights_a: First layer weights [out_features, in_features]
            weights_b: Second layer weights [out_features, in_features]
        
        Returns:
            Tuple of (reordered_weights_b, permutation_indices)
        """
                                                   
                                                      
        weights_a_norm = torch.nn.functional.normalize(weights_a, dim=1)
        weights_b_norm = torch.nn.functional.normalize(weights_b, dim=1)
        
                                   
        min_features = min(weights_a.shape[0], weights_b.shape[0])
        weights_a_norm = weights_a_norm[:min_features]
        weights_b_norm = weights_b_norm[:min_features]
        
                                          
        similarity_matrix = torch.matmul(weights_a_norm, weights_b_norm.T)
        
                                                                       
        cost_matrix = -similarity_matrix.detach().cpu().numpy()
        
                                                    
        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        
                                                         
        reordered_weights_b = weights_b[col_ind]
        
        return reordered_weights_b, col_ind
    
    @staticmethod
    def dynamic_layer_mapping(
        layers_a: dict,
        layers_b: dict,
        cka_threshold: float = 0.7
    ) -> dict:
        """
        Map layers between different architectures using CKA similarity.
        
        If Model A has 80 layers and Model B has 128 layers, this function
        calculates semantic similarities and maps only layers that serve
        equivalent structural purposes.
        
        Args:
            layers_a: Dictionary of layer_name -> weight_tensor for model A
            layers_b: Dictionary of layer_name -> weight_tensor for model B
            cka_threshold: Minimum CKA score to consider layers as matching
        
        Returns:
            Dictionary mapping layer_a_name -> layer_b_name (or None if no match)
        """
        layer_mapping = {}
        
        for layer_a_name, weights_a in layers_a.items():
            best_match = None
            best_score = 0.0
            
            for layer_b_name, weights_b in layers_b.items():
                try:
                                              
                    cka_score = ProcrustesAligner.central_kernel_alignment(
                        weights_a, weights_b, f"{layer_a_name} vs {layer_b_name}"
                    )
                    
                    if cka_score > best_score and cka_score > cka_threshold:
                        best_score = cka_score
                        best_match = layer_b_name
                except Exception as e:
                                             
                    continue
            
            layer_mapping[layer_a_name] = best_match
        
        return layer_mapping
    
    @staticmethod
    def align_mismatched_dimensions(
        tensor_a: torch.Tensor,
        tensor_b: torch.Tensor,
        target_dim: Optional[int] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Align tensors with different dimensions using padding/truncation.
        
        Args:
            tensor_a: First tensor
            tensor_b: Second tensor
            target_dim: Target dimension (auto-detected if None)
        
        Returns:
            Tuple of (aligned_tensor_a, aligned_tensor_b)
        """
        if target_dim is None:
            target_dim = max(tensor_a.shape[-1], tensor_b.shape[-1])
        
                                                     
        def align_tensor(tensor, target_dim):
            current_dim = tensor.shape[-1]
            if current_dim == target_dim:
                return tensor
            elif current_dim < target_dim:
                                
                padding_size = target_dim - current_dim
                if tensor.dim() == 1:
                    return torch.nn.functional.pad(tensor, (0, padding_size))
                else:
                    padding = [0] * (2 * (tensor.dim() - 1)) + [0, padding_size]
                    return torch.nn.functional.pad(tensor, padding)
            else:
                          
                return tensor[..., :target_dim]
        
        aligned_a = align_tensor(tensor_a, target_dim)
        aligned_b = align_tensor(tensor_b, target_dim)
        
        return aligned_a, aligned_b
