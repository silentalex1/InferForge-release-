"""
Dynamic SVD (Singular Value Decomposition) for Dimension Mismatch.

If models have different hidden dimensions (e.g., 4096 vs 5120), use SVD to
compress or expand matrix spaces into matching target dimensions while preserving
the most important mathematical "singular vectors".
"""

import torch
import numpy as np
from typing import Tuple, Optional
from scipy.linalg import svd


class DynamicSVD:
    """Dynamic SVD for handling dimension mismatches during merging."""
    
    @staticmethod
    def compress_via_svd(
        tensor: torch.Tensor,
        target_dim: int,
        retain_ratio: float = 0.95
    ) -> torch.Tensor:
        """
        Compress tensor to target dimension using SVD.
        
        Args:
            tensor: Input tensor [m, n]
            target_dim: Target dimension
            retain_ratio: Ratio of singular values to retain
        
        Returns:
            Compressed tensor
        """
                                        
        tensor_np = tensor.detach().cpu().numpy()
        
                   
        if tensor_np.ndim == 1:
            tensor_np = tensor_np.reshape(-1, 1)
        
                     
        U, s, Vt = svd(tensor_np, full_matrices=False)
        
                                                    
        total_variance = np.sum(s ** 2)
        cumulative_variance = np.cumsum(s ** 2) / total_variance
        n_components = np.argmax(cumulative_variance >= retain_ratio) + 1
        
                                   
        n_components = min(n_components, target_dim)
        
                                             
        U_reduced = U[:, :n_components]
        s_reduced = s[:n_components]
        Vt_reduced = Vt[:n_components, :]
        
        compressed = U_reduced @ np.diag(s_reduced) @ Vt_reduced
        
                                                                             
        if compressed.shape[1] != target_dim:
            if compressed.shape[1] < target_dim:
                                
                padding = target_dim - compressed.shape[1]
                compressed = np.pad(compressed, ((0, 0), (0, padding)), mode='constant')
            else:
                          
                compressed = compressed[:, :target_dim]
        
        return torch.from_numpy(compressed).to(tensor.dtype).to(tensor.device)
    
    @staticmethod
    def expand_via_svd(
        tensor: torch.Tensor,
        target_dim: int,
        expansion_method: str = "zero_pad"
    ) -> torch.Tensor:
        """
        Expand tensor to target dimension.
        
        Args:
            tensor: Input tensor [m, n]
            target_dim: Target dimension
            expansion_method: Method for expansion ("zero_pad", "interpolate", "repeat")
        
        Returns:
            Expanded tensor
        """
        current_dim = tensor.shape[-1]
        
        if current_dim >= target_dim:
            return tensor
        
        if expansion_method == "zero_pad":
                                 
            padding_size = target_dim - current_dim
            if tensor.dim() == 1:
                return torch.nn.functional.pad(tensor, (0, padding_size))
            else:
                padding = [0] * (2 * (tensor.dim() - 1)) + [0, padding_size]
                return torch.nn.functional.pad(tensor, padding)
        
        elif expansion_method == "interpolate":
                                  
            scale_factor = target_dim / current_dim
            if tensor.dim() == 1:
                indices = torch.linspace(0, current_dim - 1, target_dim).long()
                return tensor[indices]
            else:
                                                                      
                original = tensor
                expanded = torch.zeros(*tensor.shape[:-1], target_dim, 
                                      dtype=tensor.dtype, device=tensor.device)
                for i in range(original.shape[0]):
                    indices = torch.linspace(0, current_dim - 1, target_dim).long()
                    expanded[i] = original[i][indices]
                return expanded
        
        elif expansion_method == "repeat":
                                 
            repeated = tensor.repeat(1, (target_dim + current_dim - 1) // current_dim)
            return repeated[:, :target_dim] if tensor.dim() > 1 else repeated[:target_dim]
        
        else:
                                     
            return DynamicSVD.expand_via_svd(tensor, target_dim, "zero_pad")
    
    @staticmethod
    def align_dimensions_svd(
        tensor_a: torch.Tensor,
        tensor_b: torch.Tensor,
        target_dim: Optional[int] = None,
        method: str = "auto"
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Align two tensors to the same dimension using SVD.
        
        Args:
            tensor_a: First tensor
            tensor_b: Second tensor
            target_dim: Target dimension (auto-detected if None)
            method: Alignment method ("auto", "compress", "expand", "both")
        
        Returns:
            Tuple of (aligned_tensor_a, aligned_tensor_b)
        """
        dim_a = tensor_a.shape[-1]
        dim_b = tensor_b.shape[-1]
        
        if target_dim is None:
            target_dim = max(dim_a, dim_b)
        
        if method == "auto":
                                              
            if dim_a == dim_b:
                return tensor_a, tensor_b
            elif dim_a > target_dim and dim_b > target_dim:
                method = "compress"
            elif dim_a < target_dim and dim_b < target_dim:
                method = "expand"
            else:
                method = "both"
        
        if method == "compress":
                                               
            aligned_a = DynamicSVD.compress_via_svd(tensor_a, target_dim)
            aligned_b = DynamicSVD.compress_via_svd(tensor_b, target_dim)
        
        elif method == "expand":
                                             
            aligned_a = DynamicSVD.expand_via_svd(tensor_a, target_dim)
            aligned_b = DynamicSVD.expand_via_svd(tensor_b, target_dim)
        
        elif method == "both":
                                             
            if dim_a > target_dim:
                aligned_a = DynamicSVD.compress_via_svd(tensor_a, target_dim)
            else:
                aligned_a = DynamicSVD.expand_via_svd(tensor_a, target_dim)
            
            if dim_b > target_dim:
                aligned_b = DynamicSVD.compress_via_svd(tensor_b, target_dim)
            else:
                aligned_b = DynamicSVD.expand_via_svd(tensor_b, target_dim)
        
        else:
                                                
            aligned_a = DynamicSVD._simple_align(tensor_a, target_dim)
            aligned_b = DynamicSVD._simple_align(tensor_b, target_dim)
        
        return aligned_a, aligned_b
    
    @staticmethod
    def _simple_align(tensor: torch.Tensor, target_dim: int) -> torch.Tensor:
        """Simple alignment using padding/truncation."""
        current_dim = tensor.shape[-1]
        
        if current_dim == target_dim:
            return tensor
        elif current_dim < target_dim:
            padding_size = target_dim - current_dim
            if tensor.dim() == 1:
                return torch.nn.functional.pad(tensor, (0, padding_size))
            else:
                padding = [0] * (2 * (tensor.dim() - 1)) + [0, padding_size]
                return torch.nn.functional.pad(tensor, padding)
        else:
            return tensor[..., :target_dim]
    
    @staticmethod
    def calculate_optimal_target_dim(
        tensor_a: torch.Tensor,
        tensor_b: torch.Tensor,
        variance_threshold: float = 0.95
    ) -> int:
        """
        Calculate optimal target dimension based on variance preservation.
        
        Args:
            tensor_a: First tensor
            tensor_b: Second tensor
            variance_threshold: Minimum variance to preserve
        
        Returns:
            Optimal target dimension
        """
        dim_a = tensor_a.shape[-1]
        dim_b = tensor_b.shape[-1]
        
                                      
        max_dim = max(dim_a, dim_b)
        
                                                                       
        def variance_at_dim(tensor, target_dim):
            if tensor.shape[-1] <= target_dim:
                return 1.0
            compressed = DynamicSVD.compress_via_svd(tensor, target_dim, retain_ratio=variance_threshold)
            original_variance = torch.var(tensor).item()
            compressed_variance = torch.var(compressed).item()
            return compressed_variance / (original_variance + 1e-8)
        
                                                                         
        for target_dim in range(min(dim_a, dim_b), max_dim + 1):
            var_a = variance_at_dim(tensor_a, target_dim)
            var_b = variance_at_dim(tensor_b, target_dim)
            
            if var_a >= variance_threshold and var_b >= variance_threshold:
                return target_dim
        
                                                    
        return max_dim
